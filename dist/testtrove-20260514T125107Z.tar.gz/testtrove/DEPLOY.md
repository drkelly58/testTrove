# TestTrove deployment checklist

## Before go-live

- **Auth and secrets**: Copy `.env.example` to `.env` on the server. Set `APP_KEY`, database credentials, and any OAuth/API secrets. Never commit `.env` or enable debug in production without a deliberate reason.

- **CORS / trusted hosts**: Configure allowed origins and trusted proxies/hostnames so browser clients and callbacks only reach intended domains.

- **APP_DEBUG**: Set `APP_DEBUG=false` in production. Turn on only for short, controlled troubleshooting.

- **Database**: Run migrations after backup (`php artisan migrate` or your migration path). **Back up** the database before migrating on live data.

- **Document root**: Point the web server document root to `public/` (not the project root). The shipped `storage/.htaccess` denies direct web access to `storage/`.

- **Health check**: After deploy, verify HTTP 200 on your health or home route, login/session flow, and API from the SPA origin you allow in CORS.
