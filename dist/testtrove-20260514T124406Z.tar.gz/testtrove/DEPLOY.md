# TestTrove — production deployment

Concise checklist for the tarball layout (`testtrove/`). Full local and shared-hosting notes: see `SETUP.txt` in the same directory.

## Prerequisites

- PHP 8.1+ with extensions: `json`, `mbstring`, and a PDO driver for your database (`pdo_sqlite`, `pdo_mysql`, or `pdo_pgsql`).
- Apache with `mod_rewrite`, or nginx with equivalent rewrite rules.
- Document root must be the **`public/`** folder inside this tree (not the project root).

## Security warnings

- This scaffold has **no authentication** yet. Do not put sensitive data on the internet without adding auth and reviewing exposure.
- **`CORS_ORIGIN`** must exactly match the browser origin serving the SPA (scheme, host, and port). Wrong value = failed API calls from the UI. Same-origin production sites need their real HTTPS origin here, not `http://localhost:5173`.

## Ordered deploy checklist

1. **Extract** the archive on the server (yields one top-level folder `testtrove/`):
   ```bash
   tar -xzf testtrove-<UTC-timestamp>.tar.gz
   ```

2. **Web server** — set document root to `testtrove/public/`. Sample Apache vhost: `deploy/apache/testtrove-vhost.conf` (edit paths). Included `public/.htaccess` routes `/api/*` to `index.php` and client routes to `index.html`. For PHP’s built-in server locally, use `public/router.php` as router script (see `SETUP.txt`).

3. **`storage/`** — must be writable by the PHP user for SQLite or logs. It ships empty with `.gitkeep` and `storage/.htaccess` (`Require all denied`) so Apache does not serve files from that directory. Adjust nginx if you use it.

4. **Environment** — from `testtrove/`:
   ```bash
   cp .env.example .env
   ```
   Edit `.env` and set at least:
   - **`APP_ENV`** — e.g. `production`.
   - **`APP_DEBUG`** — use `0` or `false` in production (API error detail follows this).
   - **`CORS_ORIGIN`** — production browser origin (see warning above).
   - **`DB_DRIVER`** — `sqlite`, `mysql`, or `pgsql` (aliases: `mariadb`, `postgres`, `postgresql`).

5. **Database connection**
   - **SQLite (`DB_DRIVER=sqlite`):** set **`DB_PATH`** to a path the web user can create/write (absolute path under `storage/` is safest, e.g. `/var/www/.../testtrove/storage/app.sqlite`). Schema reference: `database/schema.sqlite.sql`; tables are created on first app use where applicable.
   - **MySQL / MariaDB:** create an empty database first. Set **`DB_HOST`**, **`DB_PORT`**, **`DB_DATABASE`**, **`DB_USERNAME`**, **`DB_PASSWORD`**, or **`DB_SOCKET`** instead of host/port. MySQL 8.0.16+ for CHECK constraints. Schema: `database/schema.mysql.sql`.
   - **PostgreSQL:** same variables as MySQL-style; default **`DB_PORT=5432`**. Schema: `database/schema.pgsql.sql`.

6. **Composer on server (optional)** — if `composer.json` / `composer.lock` change after this tarball was built, run from `testtrove/`:
   ```bash
   composer install --no-dev --optimize-autoloader --no-interaction
   ```
   The tarball already contains a production `vendor/` from `composer install --no-dev --optimize-autoloader`.

7. **Demo seed (optional)** — set **`APP_SEED=1`** once in `.env` to insert demo project/suite/case when the projects table is empty; unset afterward.

8. **Reload** Apache/nginx and test the UI and an API route.

## What is in this bundle

| Path | Purpose |
|------|---------|
| `src/` | PHP application (Slim routes, controllers) |
| `public/` | Built SPA (`index.html`, `assets/*`), `index.php`, `.htaccess`, `router.php`, `favicon.svg` |
| `database/` | SQL schema files per engine |
| `deploy/` | Example Apache configuration |
| `vendor/` | Autoloaded production dependencies only |
| `composer.json`, `composer.lock` | Dependency metadata |
| `.env.example` | Variable template; copy to `.env` |
| `SETUP.txt` | Longer setup guide (extensions, dev workflow, DB vars) |
| `storage/` | Empty except placeholders; per-deployment SQLite lives here if used |
| `DEPLOY.md` | This file |

## Post-deploy verification

- Confirm `public/index.html` and `public/assets/*` load (no 404 on hashed assets).
- Confirm `vendor/autoload.php` exists (Composer autoload).
- Confirm no SQLite WAL/SHM from dev are required — a fresh `DB_PATH` is created as needed.
- With **`APP_DEBUG=0`**, confirm API errors do not leak internal details to browsers.

## Cross-references

- **`SETUP.txt`** — requirements list, `composer install` for dev trees, Vite dev proxy, `php -S` example.
- **`.env.example`** — authoritative names: `DB_DRIVER`, `DB_PATH`, `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`, `DB_SOCKET`, `CORS_ORIGIN`, `APP_SEED`.
