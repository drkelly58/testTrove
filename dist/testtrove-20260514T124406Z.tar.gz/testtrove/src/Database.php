<?php

declare(strict_types=1);

namespace App;

use PDO;
use PDOException;

final class Database
{
    /** @return 'sqlite'|'mysql'|'pgsql' */
    public static function normalizeDriver(string $raw): string
    {
        $d = strtolower(trim($raw));
        if ($d === '' || $d === 'sqlite') {
            return 'sqlite';
        }
        if ($d === 'mysql' || $d === 'mariadb') {
            return 'mysql';
        }
        if ($d === 'pgsql' || $d === 'postgres' || $d === 'postgresql') {
            return 'pgsql';
        }
        throw new \InvalidArgumentException(
            'Unsupported DB_DRIVER "' . $raw . '". Use sqlite, mysql, or pgsql.'
        );
    }

    public static function fromEnv(string $root): PDO
    {
        $driver = self::normalizeDriver($_ENV['DB_DRIVER'] ?? 'sqlite');

        return match ($driver) {
            'sqlite' => self::pdoSqlite(self::sqlitePath($root)),
            'mysql' => self::pdoMysql(
                $_ENV['DB_HOST'] ?? '127.0.0.1',
                (int) ($_ENV['DB_PORT'] ?? 3306),
                $_ENV['DB_DATABASE'] ?? 'testtrove',
                $_ENV['DB_USERNAME'] ?? 'root',
                $_ENV['DB_PASSWORD'] ?? '',
                $_ENV['DB_SOCKET'] ?? null,
            ),
            'pgsql' => self::pdoPgsql(
                $_ENV['DB_HOST'] ?? '127.0.0.1',
                (int) ($_ENV['DB_PORT'] ?? 5432),
                $_ENV['DB_DATABASE'] ?? 'testtrove',
                $_ENV['DB_USERNAME'] ?? 'postgres',
                $_ENV['DB_PASSWORD'] ?? '',
            ),
        };
    }

    /** Absolute path to SQLite file; relative DB_PATH is resolved from project root. */
    private static function sqlitePath(string $root): string
    {
        $raw = isset($_ENV['DB_PATH']) ? trim((string) $_ENV['DB_PATH']) : '';
        if ($raw === '') {
            return $root . '/storage/app.sqlite';
        }
        if ($raw[0] === '/') {
            return $raw;
        }
        return $root . '/' . ltrim($raw, '/');
    }

    /** Absolute SQLite database file path (for messages and permission checks). */
    public static function sqlitePathFromEnv(string $root): string
    {
        return self::sqlitePath($root);
    }

    /**
     * Fail fast when SQLite cannot persist writes (avoids obscure errors on INSERT).
     *
     * @throws \RuntimeException
     */
    public static function assertSqliteIsWritable(string $dbFilePath): void
    {
        $dir = dirname($dbFilePath);
        if (!is_dir($dir)) {
            throw new \RuntimeException('SQLite database directory does not exist: ' . $dir);
        }
        if (!is_writable($dir)) {
            throw new \RuntimeException(
                'SQLite directory is not writable: ' . $dir . '. '
                . 'The web server user must be able to create and update the database file and sidecar files (-wal, -shm, -journal). '
                . 'Typical fix: chown/chmod that directory (and the .sqlite file if it already exists), or set DB_PATH in .env to a writable path.'
            );
        }
        if (is_file($dbFilePath) && !is_writable($dbFilePath)) {
            throw new \RuntimeException(
                'SQLite database file is not writable: ' . $dbFilePath . '. '
                . 'Adjust ownership/permissions so the PHP process can write to this file.'
            );
        }
    }

    public static function schemaPath(string $root, string $driver): string
    {
        $file = match ($driver) {
            'sqlite' => 'schema.sqlite.sql',
            'mysql' => 'schema.mysql.sql',
            'pgsql' => 'schema.pgsql.sql',
        };
        return $root . '/database/' . $file;
    }

    public static function migrate(PDO $pdo, string $driver, string $root): void
    {
        $path = self::schemaPath($root, $driver);
        if (!is_readable($path)) {
            throw new \RuntimeException('Schema file not readable: ' . $path);
        }
        $sql = file_get_contents($path);
        if ($sql === false || trim($sql) === '') {
            throw new \RuntimeException('Schema file empty: ' . $path);
        }

        if ($driver === 'sqlite') {
            $pdo->exec($sql);
            self::sqliteAdditiveMigrations($pdo);
            self::sectionAdditiveMigrations($pdo, $driver);

            return;
        }

        self::execScriptStatements($pdo, $sql);
        self::sectionAdditiveMigrations($pdo, $driver);
        self::testRunsSectionAndRunKindMigrations($pdo, $driver);
    }

    /**
     * SQLite ships CREATE TABLE IF NOT EXISTS only for new DBs; existing files need column adds.
     */
    private static function sqliteAdditiveMigrations(PDO $pdo): void
    {
        /*
         * SQLite CHECK enforcement: rows are validated against the table definition stored in sqlite_master.
         * Adding `section` to run_kind requires rebuilding `test_runs` when the live table still has the old CHECK;
         * see {@see sqliteRebuildTestRunsIfSectionRunKindDisallowed}.
         *
         * test_runs.section_id ON DELETE SET NULL: deleting a section clears the pointer on historical runs while
         * leaving the run row; run_items for cases in that section are removed via CASCADE on test_cases.
         */
        $alters = [
            'ALTER TABLE test_runs ADD COLUMN suite_id INTEGER REFERENCES test_suites(id) ON DELETE SET NULL',
            "ALTER TABLE test_runs ADD COLUMN run_kind TEXT NOT NULL DEFAULT 'full_suite'",
            'ALTER TABLE test_runs ADD COLUMN section_id INTEGER REFERENCES test_sections(id) ON DELETE SET NULL',
        ];
        foreach ($alters as $sql) {
            try {
                $pdo->exec($sql);
            } catch (PDOException $e) {
                $msg = strtolower($e->getMessage());
                if (!str_contains($msg, 'duplicate column name') && !str_contains($msg, 'duplicate column')) {
                    throw $e;
                }
            }
        }
        try {
            $pdo->exec('CREATE INDEX IF NOT EXISTS idx_runs_suite ON test_runs(suite_id)');
        } catch (PDOException $e) {
            $msg = strtolower($e->getMessage());
            if (!str_contains($msg, 'no such column') && !str_contains($msg, 'duplicate')) {
                throw $e;
            }
        }
        try {
            $pdo->exec('CREATE INDEX IF NOT EXISTS idx_runs_section ON test_runs(section_id)');
        } catch (PDOException $e) {
            $msg = strtolower($e->getMessage());
            if (!str_contains($msg, 'no such column') && !str_contains($msg, 'duplicate')) {
                throw $e;
            }
        }

        self::sqliteRebuildTestRunsIfSectionRunKindDisallowed($pdo);
    }

    /**
     * Idempotent: if {@see sqliteTestRunsAcceptsRunKindSection} fails (old CHECK rejects run_kind = section),
     * copy test_runs into a new table whose CHECK includes section, then swap.
     */
    private static function sqliteRebuildTestRunsIfSectionRunKindDisallowed(PDO $pdo): void
    {
        if (self::sqliteTestRunsAcceptsRunKindSection($pdo)) {
            return;
        }

        $pdo->exec('BEGIN IMMEDIATE');
        try {
            $pdo->exec(
                "CREATE TABLE test_runs_new (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  suite_id INTEGER REFERENCES test_suites(id) ON DELETE SET NULL,
  section_id INTEGER REFERENCES test_sections(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  run_kind TEXT NOT NULL DEFAULT 'full_suite' CHECK (run_kind IN ('full_suite', 'section', 'run_book')),
  state TEXT NOT NULL DEFAULT 'open' CHECK (state IN ('open', 'locked', 'archived')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
)"
            );
            $pdo->exec(
                'INSERT INTO test_runs_new (id, project_id, suite_id, section_id, name, run_kind, state, created_at)
                 SELECT id, project_id, suite_id, section_id, name, run_kind, state, created_at FROM test_runs'
            );
            $pdo->exec('DROP TABLE test_runs');
            $pdo->exec('ALTER TABLE test_runs_new RENAME TO test_runs');
            $pdo->exec('CREATE INDEX IF NOT EXISTS idx_runs_project ON test_runs(project_id)');
            $pdo->exec('CREATE INDEX IF NOT EXISTS idx_runs_suite ON test_runs(suite_id)');
            $pdo->exec('CREATE INDEX IF NOT EXISTS idx_runs_section ON test_runs(section_id)');
            $maxId = (int) $pdo->query('SELECT COALESCE(MAX(id), 0) FROM test_runs')->fetchColumn();
            if ($maxId > 0) {
                $pdo->exec("DELETE FROM sqlite_sequence WHERE name = 'test_runs'");
                $pdo->exec('INSERT INTO sqlite_sequence (name, seq) VALUES (\'test_runs\', ' . $maxId . ')');
            }
            $pdo->exec('COMMIT');
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->exec('ROLLBACK');
            }
            throw $e;
        }
    }

    /**
     * Probe whether INSERT with run_kind = section satisfies the stored CHECK (savepoint + rollback).
     * Falls back to sqlite_master SQL inspection when there are no projects (cannot insert a valid row).
     */
    private static function sqliteTestRunsAcceptsRunKindSection(PDO $pdo): bool
    {
        $pidRaw = $pdo->query('SELECT id FROM projects LIMIT 1')->fetchColumn();
        if ($pidRaw === false) {
            $sql = $pdo->query("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'test_runs'")->fetchColumn();
            if (!is_string($sql)) {
                return true;
            }
            // Literal 'section' as a run_kind value (not the section_id column name).
            return str_contains($sql, "'section'") && str_contains($sql, 'run_kind');
        }

        $pid = (int) $pidRaw;
        try {
            $pdo->exec('SAVEPOINT sp_run_kind_section');
            $stmt = $pdo->prepare(
                "INSERT INTO test_runs (project_id, suite_id, section_id, name, run_kind, state)
                 VALUES (:pid, NULL, NULL, '__tt_migration_probe__', 'section', 'open')"
            );
            $stmt->execute(['pid' => $pid]);
            $pdo->exec('ROLLBACK TO SAVEPOINT sp_run_kind_section');
            $pdo->exec('RELEASE SAVEPOINT sp_run_kind_section');

            return true;
        } catch (PDOException $e) {
            try {
                $pdo->exec('ROLLBACK TO SAVEPOINT sp_run_kind_section');
            } catch (PDOException) {
                /* ignore */
            }
            try {
                $pdo->exec('RELEASE SAVEPOINT sp_run_kind_section');
            } catch (PDOException) {
                /* ignore */
            }
            $msg = strtolower($e->getMessage());
            if (str_contains($msg, 'check') || str_contains($msg, 'constraint')) {
                return false;
            }
            throw $e;
        }
    }

    /**
     * MySQL / PostgreSQL: add section_id + idx when missing, widen run_kind CHECK to include section (idempotent).
     */
    private static function testRunsSectionAndRunKindMigrations(PDO $pdo, string $driver): void
    {
        if ($driver === 'mysql') {
            self::safeExec(
                $pdo,
                'ALTER TABLE test_runs ADD COLUMN section_id BIGINT UNSIGNED NULL',
                ['duplicate column name', 'duplicate column'],
            );
            self::safeExec(
                $pdo,
                'ALTER TABLE test_runs ADD CONSTRAINT fk_test_runs_section FOREIGN KEY (section_id) REFERENCES test_sections (id) ON DELETE SET NULL',
                ['duplicate', 'already exists'],
            );
            self::safeExec($pdo, 'CREATE INDEX idx_runs_section ON test_runs (section_id)', ['duplicate']);
            self::mysqlUpgradeTestRunsRunKindCheck($pdo);

            return;
        }
        if ($driver === 'pgsql') {
            $pdo->exec(
                'ALTER TABLE test_runs ADD COLUMN IF NOT EXISTS section_id BIGINT REFERENCES test_sections (id) ON DELETE SET NULL'
            );
            self::safeExec($pdo, 'CREATE INDEX IF NOT EXISTS idx_runs_section ON test_runs (section_id)', ['duplicate']);
            self::pgsqlUpgradeTestRunsRunKindCheck($pdo);
        }
    }

    private static function mysqlUpgradeTestRunsRunKindCheck(PDO $pdo): void
    {
        $stmt = $pdo->query(
            "SELECT cc.constraint_name
             FROM information_schema.check_constraints cc
             INNER JOIN information_schema.table_constraints tc
               ON tc.constraint_schema = cc.constraint_schema
              AND tc.constraint_name = cc.constraint_name
             WHERE tc.table_schema = DATABASE()
               AND tc.table_name = 'test_runs'
               AND tc.constraint_type = 'CHECK'
               AND cc.check_clause LIKE '%run_kind%'
               AND cc.check_clause NOT LIKE '%section%'"
        );
        if ($stmt === false) {
            return;
        }
        $names = $stmt->fetchAll(PDO::FETCH_COLUMN);
        foreach ($names as $name) {
            if (!is_string($name) || $name === '') {
                continue;
            }
            $ident = '`' . str_replace('`', '``', $name) . '`';
            self::safeExec(
                $pdo,
                "ALTER TABLE test_runs DROP CHECK {$ident}",
                ['check', "doesn't exist", 'unknown', 'failed', 'exist'],
            );
        }
        self::safeExec(
            $pdo,
            "ALTER TABLE test_runs ADD CONSTRAINT test_runs_run_kind_chk CHECK (run_kind IN ('full_suite', 'section', 'run_book'))",
            ['duplicate', 'already exists'],
        );
    }

    private static function pgsqlUpgradeTestRunsRunKindCheck(PDO $pdo): void
    {
        $stmt = $pdo->query(
            "SELECT c.conname, pg_get_constraintdef(c.oid) AS def
             FROM pg_constraint c
             INNER JOIN pg_class rel ON rel.oid = c.conrelid
             INNER JOIN pg_namespace nsp ON nsp.oid = rel.relnamespace
             WHERE rel.relname = 'test_runs'
               AND nsp.nspname = CURRENT_SCHEMA()
               AND c.contype = 'c'"
        );
        if ($stmt === false) {
            return;
        }
        while (($row = $stmt->fetch(PDO::FETCH_ASSOC)) !== false) {
            $def = strtolower((string) ($row['def'] ?? ''));
            if (!str_contains($def, 'run_kind')) {
                continue;
            }
            if (str_contains($def, 'section')) {
                continue;
            }
            $name = (string) ($row['conname'] ?? '');
            if ($name === '') {
                continue;
            }
            $ident = '"' . str_replace('"', '""', $name) . '"';
            self::safeExec($pdo, "ALTER TABLE test_runs DROP CONSTRAINT {$ident}", ['does not exist', 'undefined']);
        }
        self::safeExec(
            $pdo,
            "ALTER TABLE test_runs ADD CONSTRAINT test_runs_run_kind_chk CHECK (run_kind IN ('full_suite', 'section', 'run_book'))",
            ['already exists', 'duplicate'],
        );
    }

    /**
     * Adds the suite → section → case layer to existing databases without deleting data.
     */
    private static function sectionAdditiveMigrations(PDO $pdo, string $driver): void
    {
        $pdo->exec(self::testSectionsCreateSql($driver));
        self::safeExec($pdo, self::sectionIdAddColumnSql($driver), ['duplicate column name', 'duplicate column']);

        self::createDefaultSections($pdo, $driver);
        self::backfillCaseSections($pdo);

        if ($driver === 'mysql') {
            self::safeExec($pdo, 'CREATE INDEX idx_sections_suite ON test_sections(suite_id)', ['duplicate']);
            self::safeExec($pdo, 'CREATE INDEX idx_cases_section ON test_cases(section_id)', ['duplicate']);
            self::safeExec(
                $pdo,
                'ALTER TABLE test_cases ADD CONSTRAINT fk_test_cases_section FOREIGN KEY (section_id) REFERENCES test_sections (id) ON DELETE CASCADE',
                ['duplicate', 'already exists']
            );
            self::safeExec($pdo, 'ALTER TABLE test_cases MODIFY section_id BIGINT UNSIGNED NOT NULL', []);
        } elseif ($driver === 'pgsql') {
            self::safeExec($pdo, 'CREATE INDEX IF NOT EXISTS idx_sections_suite ON test_sections(suite_id)', ['duplicate']);
            self::safeExec($pdo, 'CREATE INDEX IF NOT EXISTS idx_cases_section ON test_cases(section_id)', ['duplicate']);
            self::safeExec(
                $pdo,
                'ALTER TABLE test_cases ADD CONSTRAINT fk_test_cases_section FOREIGN KEY (section_id) REFERENCES test_sections (id) ON DELETE CASCADE',
                ['already exists', 'duplicate']
            );
            self::safeExec($pdo, 'ALTER TABLE test_cases ALTER COLUMN section_id SET NOT NULL', []);
        } else {
            self::safeExec($pdo, 'CREATE INDEX IF NOT EXISTS idx_sections_suite ON test_sections(suite_id)', ['duplicate']);
            self::safeExec($pdo, 'CREATE INDEX IF NOT EXISTS idx_cases_section ON test_cases(section_id)', ['duplicate']);
        }
    }

    private static function testSectionsCreateSql(string $driver): string
    {
        return match ($driver) {
            'mysql' => "CREATE TABLE IF NOT EXISTS test_sections (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  suite_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(500) NOT NULL,
  precondition TEXT,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_sections_suite (suite_id),
  CONSTRAINT fk_test_sections_suite FOREIGN KEY (suite_id) REFERENCES test_suites (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'pgsql' => 'CREATE TABLE IF NOT EXISTS test_sections (
  id BIGSERIAL PRIMARY KEY,
  suite_id BIGINT NOT NULL REFERENCES test_suites (id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  precondition TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
)',
            default => "CREATE TABLE IF NOT EXISTS test_sections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  suite_id INTEGER NOT NULL REFERENCES test_suites(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  precondition TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
)",
        };
    }

    private static function sectionIdAddColumnSql(string $driver): string
    {
        return match ($driver) {
            'mysql' => 'ALTER TABLE test_cases ADD COLUMN section_id BIGINT UNSIGNED NULL AFTER suite_id',
            'pgsql' => 'ALTER TABLE test_cases ADD COLUMN IF NOT EXISTS section_id BIGINT',
            default => 'ALTER TABLE test_cases ADD COLUMN section_id INTEGER REFERENCES test_sections(id) ON DELETE CASCADE',
        };
    }

    private static function createDefaultSections(PDO $pdo, string $driver): void
    {
        if ($driver === 'mysql') {
            $pdo->exec(
                "INSERT INTO test_sections (suite_id, name, precondition, sort_order)
                 SELECT s.id, 'Default', NULL, 0
                 FROM test_suites s
                 LEFT JOIN test_sections ts ON ts.suite_id = s.id
                 WHERE ts.id IS NULL"
            );
            return;
        }

        $pdo->exec(
            "INSERT INTO test_sections (suite_id, name, precondition, sort_order)
             SELECT s.id, 'Default', NULL, 0
             FROM test_suites s
             WHERE NOT EXISTS (SELECT 1 FROM test_sections ts WHERE ts.suite_id = s.id)"
        );
    }

    private static function backfillCaseSections(PDO $pdo): void
    {
        $pdo->exec(
            "UPDATE test_cases
             SET section_id = (
               SELECT ts.id FROM test_sections ts
               WHERE ts.suite_id = test_cases.suite_id
               ORDER BY CASE WHEN ts.name = 'Default' THEN 0 ELSE 1 END, ts.sort_order, ts.id
               LIMIT 1
             )
             WHERE section_id IS NULL"
        );
    }

    /**
     * @param list<string> $ignoreNeedles
     */
    private static function safeExec(PDO $pdo, string $sql, array $ignoreNeedles): void
    {
        try {
            $pdo->exec($sql);
        } catch (PDOException $e) {
            $msg = strtolower($e->getMessage());
            foreach ($ignoreNeedles as $needle) {
                if ($needle !== '' && str_contains($msg, strtolower($needle))) {
                    return;
                }
            }
            throw $e;
        }
    }

    /**
     * Run a SQL file as separate statements (required for MySQL PDO without MULTI_STATEMENTS).
     */
    private static function execScriptStatements(PDO $pdo, string $sql): void
    {
        $lines = explode("\n", $sql);
        $buf = [];
        foreach ($lines as $line) {
            $t = trim($line);
            if ($t === '' || str_starts_with($t, '--')) {
                continue;
            }
            $buf[] = $line;
        }
        $clean = implode("\n", $buf);
        $parts = preg_split('/;\s*\n/', $clean) ?: [];
        foreach ($parts as $chunk) {
            $chunk = trim($chunk);
            if ($chunk === '') {
                continue;
            }
            if (!str_ends_with($chunk, ';')) {
                $chunk .= ';';
            }
            $pdo->exec($chunk);
        }
    }

    private static function pdoSqlite(string $path): PDO
    {
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        $dsn = 'sqlite:' . $path;
        try {
            $pdo = new PDO($dsn, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            throw new PDOException('Cannot open SQLite database: ' . $e->getMessage(), (int) $e->getCode(), $e);
        }
        $pdo->exec('PRAGMA foreign_keys = ON;');
        return $pdo;
    }

    private static function pdoMysql(
        string $host,
        int $port,
        string $database,
        string $username,
        string $password,
        ?string $socket,
    ): PDO {
        if ($socket !== null && $socket !== '') {
            $dsn = sprintf('mysql:unix_socket=%s;dbname=%s;charset=utf8mb4', $socket, $database);
        } else {
            $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $host, $port, $database);
        }
        try {
            return new PDO($dsn, $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            throw new PDOException('Cannot connect to MySQL: ' . $e->getMessage(), (int) $e->getCode(), $e);
        }
    }

    private static function pdoPgsql(string $host, int $port, string $database, string $username, string $password): PDO
    {
        $dsn = sprintf('pgsql:host=%s;port=%d;dbname=%s', $host, $port, $database);
        try {
            return new PDO($dsn, $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            throw new PDOException('Cannot connect to PostgreSQL: ' . $e->getMessage(), (int) $e->getCode(), $e);
        }
    }
}
