<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Database;
use App\JsonRequestBody;
use App\JsonResponse;
use PDO;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

/**
 * Test execution: full-suite and section-scoped snapshots; {@see run_kind} run_book reserved for custom “run books”.
 */
final class RunController
{
    private const RESULTS = ['untested', 'pass', 'fail', 'blocked', 'skipped'];

    private const RUN_STATES = ['open', 'locked', 'archived'];

    public function __construct(private readonly PDO $pdo)
    {
    }

    /** GET /api/projects/{projectId}/runs */
    public function listByProject(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $projectId = (int) ($args['projectId'] ?? 0);
        if (!$this->projectExists($projectId)) {
            return JsonResponse::error('project not found', 404);
        }

        $stmt = $this->pdo->prepare(
            'SELECT r.id, r.project_id, r.suite_id, r.section_id, r.name, r.run_kind, r.state, r.created_at,
                    s.name AS suite_name,
                    sec.name AS section_name,
                    (SELECT COUNT(*) FROM test_run_items i WHERE i.run_id = r.id) AS item_count,
                    (SELECT COUNT(*) FROM test_run_items i WHERE i.run_id = r.id AND i.result = \'pass\') AS passed,
                    (SELECT COUNT(*) FROM test_run_items i WHERE i.run_id = r.id AND i.result = \'fail\') AS failed,
                    (SELECT COUNT(*) FROM test_run_items i WHERE i.run_id = r.id AND i.result = \'untested\') AS untested
             FROM test_runs r
             LEFT JOIN test_suites s ON s.id = r.suite_id
             LEFT JOIN test_sections sec ON sec.id = r.section_id
             WHERE r.project_id = :pid
             ORDER BY r.id DESC'
        );
        $stmt->execute(['pid' => $projectId]);
        $rows = $stmt->fetchAll();
        foreach ($rows as &$row) {
            $row['item_count'] = (int) ($row['item_count'] ?? 0);
            $row['passed'] = (int) ($row['passed'] ?? 0);
            $row['failed'] = (int) ($row['failed'] ?? 0);
            $row['untested'] = (int) ($row['untested'] ?? 0);
            if (array_key_exists('section_id', $row) && $row['section_id'] !== null && $row['section_id'] !== '') {
                $row['section_id'] = (int) $row['section_id'];
            } else {
                $row['section_id'] = null;
            }
            if (!isset($row['section_name']) || $row['section_name'] === '') {
                $row['section_name'] = null;
            }
        }
        unset($row);

        return JsonResponse::encode($response, ['data' => $rows]);
    }

    /** POST /api/suites/{suiteId}/runs — snapshot all cases in the suite into a new run. */
    public function createForSuite(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $suiteId = (int) ($args['suiteId'] ?? 0);
        $suite = $this->fetchSuiteRow($suiteId);
        if ($suite === null) {
            return JsonResponse::error('suite not found', 404);
        }

        $projectId = (int) $suite['project_id'];
        $suiteName = (string) $suite['name'];

        $customName = null;
        try {
            $data = JsonRequestBody::decodeAssocOptional($request);
        } catch (\JsonException) {
            return JsonResponse::error('Invalid JSON body', 422);
        }
        if (isset($data['name'])) {
            $customName = trim((string) $data['name']);
            if ($customName === '') {
                $customName = null;
            }
        }

        $defaultName = 'Run: ' . $suiteName . ' · ' . gmdate('Y-m-d H:i') . ' UTC';
        $name = $customName ?? $defaultName;

        $caseStmt = $this->pdo->prepare(
            'SELECT c.id
             FROM test_cases c
             INNER JOIN test_sections s ON s.id = c.section_id
             WHERE c.suite_id = :sid
             ORDER BY s.sort_order ASC, s.id ASC, c.id ASC'
        );
        $caseStmt->execute(['sid' => $suiteId]);
        $caseIds = $caseStmt->fetchAll(PDO::FETCH_COLUMN);
        if (!is_array($caseIds)) {
            $caseIds = [];
        }
        $caseIds = array_map('intval', $caseIds);

        $this->pdo->beginTransaction();
        try {
            $insRun = $this->pdo->prepare(
                'INSERT INTO test_runs (project_id, suite_id, section_id, name, run_kind, state)
                 VALUES (:project_id, :suite_id, NULL, :name, \'full_suite\', \'open\')'
            );
            $insRun->execute([
                'project_id' => $projectId,
                'suite_id' => $suiteId,
                'name' => $name,
            ]);
            $runId = (int) $this->pdo->lastInsertId();

            $insItem = $this->pdo->prepare(
                'INSERT INTO test_run_items (run_id, case_id, result) VALUES (:run_id, :case_id, \'untested\')'
            );
            foreach ($caseIds as $cid) {
                $insItem->execute(['run_id' => $runId, 'case_id' => $cid]);
            }

            $this->pdo->commit();
        } catch (\Throwable $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            $msg = 'Could not create run: ' . $e->getMessage();
            if ($this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite'
                && self::looksLikeSqliteReadonlyError($e->getMessage())) {
                $root = dirname(__DIR__, 2);
                $msg .= ' Database file: ' . Database::sqlitePathFromEnv($root)
                    . '. The PHP user needs write access to this file and its directory (SQLite creates -wal / -journal beside the file).';
            }

            return JsonResponse::error($msg, 500);
        }

        return JsonResponse::encode(
            $response,
            [
                'data' => [
                    'id' => $runId,
                    'project_id' => $projectId,
                    'suite_id' => $suiteId,
                    'section_id' => null,
                    'section_name' => null,
                    'name' => $name,
                    'run_kind' => 'full_suite',
                    'state' => 'open',
                    'case_count' => count($caseIds),
                ],
            ],
            201
        );
    }

    /** POST /api/sections/{sectionId}/runs — snapshot cases in this section into a new run. */
    public function createForSection(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $sectionId = (int) ($args['sectionId'] ?? 0);
        $section = $this->fetchSectionWithSuite($sectionId);
        if ($section === null) {
            return JsonResponse::error('section not found', 404);
        }

        $suiteId = (int) $section['suite_id'];
        $projectId = (int) $section['project_id'];
        $suiteName = (string) $section['suite_name'];
        $sectionName = (string) $section['section_name'];

        $customName = null;
        try {
            $data = JsonRequestBody::decodeAssocOptional($request);
        } catch (\JsonException) {
            return JsonResponse::error('Invalid JSON body', 422);
        }
        if (isset($data['name'])) {
            $customName = trim((string) $data['name']);
            if ($customName === '') {
                $customName = null;
            }
        }

        $defaultName = 'Run: ' . $suiteName . ' / ' . $sectionName . ' · ' . gmdate('Y-m-d H:i') . ' UTC';
        $name = $customName ?? $defaultName;

        $caseStmt = $this->pdo->prepare(
            'SELECT c.id
             FROM test_cases c
             WHERE c.section_id = :sec
             ORDER BY c.id ASC'
        );
        $caseStmt->execute(['sec' => $sectionId]);
        $caseIds = $caseStmt->fetchAll(PDO::FETCH_COLUMN);
        if (!is_array($caseIds)) {
            $caseIds = [];
        }
        $caseIds = array_map('intval', $caseIds);

        $this->pdo->beginTransaction();
        try {
            $insRun = $this->pdo->prepare(
                'INSERT INTO test_runs (project_id, suite_id, section_id, name, run_kind, state)
                 VALUES (:project_id, :suite_id, :section_id, :name, \'section\', \'open\')'
            );
            $insRun->execute([
                'project_id' => $projectId,
                'suite_id' => $suiteId,
                'section_id' => $sectionId,
                'name' => $name,
            ]);
            $runId = (int) $this->pdo->lastInsertId();

            $insItem = $this->pdo->prepare(
                'INSERT INTO test_run_items (run_id, case_id, result) VALUES (:run_id, :case_id, \'untested\')'
            );
            foreach ($caseIds as $cid) {
                $insItem->execute(['run_id' => $runId, 'case_id' => $cid]);
            }

            $this->pdo->commit();
        } catch (\Throwable $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            $msg = 'Could not create run: ' . $e->getMessage();
            if ($this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite'
                && self::looksLikeSqliteReadonlyError($e->getMessage())) {
                $root = dirname(__DIR__, 2);
                $msg .= ' Database file: ' . Database::sqlitePathFromEnv($root)
                    . '. The PHP user needs write access to this file and its directory (SQLite creates -wal / -journal beside the file).';
            }

            return JsonResponse::error($msg, 500);
        }

        return JsonResponse::encode(
            $response,
            [
                'data' => [
                    'id' => $runId,
                    'project_id' => $projectId,
                    'suite_id' => $suiteId,
                    'section_id' => $sectionId,
                    'section_name' => $sectionName,
                    'name' => $name,
                    'run_kind' => 'section',
                    'state' => 'open',
                    'case_count' => count($caseIds),
                ],
            ],
            201
        );
    }

    /** GET /api/runs/{runId} */
    public function get(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $runId = (int) ($args['runId'] ?? 0);
        $run = $this->fetchRunRow($runId);
        if ($run === null) {
            return JsonResponse::error('run not found', 404);
        }

        $itemsStmt = $this->pdo->prepare(
            'SELECT i.id, i.run_id, i.case_id, i.result, i.notes, i.executed_at,
                    c.section_id, s.name AS section_name,
                    c.title, c.precondition, c.priority, c.status, c.steps_json
             FROM test_run_items i
             INNER JOIN test_cases c ON c.id = i.case_id
             INNER JOIN test_sections s ON s.id = c.section_id
             WHERE i.run_id = :rid
             ORDER BY s.sort_order ASC, s.id ASC, c.id ASC'
        );
        $itemsStmt->execute(['rid' => $runId]);
        $items = $itemsStmt->fetchAll();
        foreach ($items as &$row) {
            $row['steps'] = json_decode((string) $row['steps_json'], true) ?? [];
            unset($row['steps_json']);
        }
        unset($row);

        return JsonResponse::encode($response, [
            'data' => [
                'run' => $run,
                'items' => $items,
            ],
        ]);
    }

    /** PATCH /api/runs/{runId} */
    public function update(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $runId = (int) ($args['runId'] ?? 0);
        if ($runId <= 0) {
            return JsonResponse::error('Invalid run id', 422);
        }
        if ($this->fetchRunRow($runId) === null) {
            return JsonResponse::error('run not found', 404);
        }

        try {
            $data = JsonRequestBody::decodeAssoc($request);
        } catch (\JsonException $e) {
            return JsonResponse::error('Invalid JSON: ' . $e->getMessage(), 422);
        }

        $sets = [];
        $params = ['id' => $runId];
        if (array_key_exists('name', $data)) {
            $name = trim((string) $data['name']);
            if ($name === '') {
                return JsonResponse::error('name cannot be empty', 422);
            }
            $sets[] = 'name = :name';
            $params['name'] = $name;
        }
        if (array_key_exists('state', $data)) {
            $state = strtolower(trim((string) $data['state']));
            if (!in_array($state, self::RUN_STATES, true)) {
                return JsonResponse::error('state must be one of: ' . implode(', ', self::RUN_STATES), 422);
            }
            $sets[] = 'state = :state';
            $params['state'] = $state;
        }
        if ($sets === []) {
            return JsonResponse::error('No run fields to update', 422);
        }

        try {
            $upd = $this->pdo->prepare('UPDATE test_runs SET ' . implode(', ', $sets) . ' WHERE id = :id');
            $upd->execute($params);
        } catch (\PDOException $e) {
            error_log('PATCH /api/runs/' . $runId . ' failed: ' . $e->getMessage());
            $debug = ($_ENV['APP_DEBUG'] ?? '') === '1' || strtolower((string) ($_ENV['APP_DEBUG'] ?? '')) === 'true';

            return JsonResponse::error($debug ? $e->getMessage() : 'Database error while updating the run.', 500);
        }

        $row = $this->fetchRunRow($runId);
        if ($row === null) {
            return JsonResponse::error('run not found', 404);
        }

        return JsonResponse::encode($response, ['data' => $row]);
    }

    /** PATCH /api/runs/{runId}/items/{itemId} */
    public function updateItem(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $runId = (int) ($args['runId'] ?? 0);
        $itemId = (int) ($args['itemId'] ?? 0);

        if ($this->fetchRunRow($runId) === null) {
            return JsonResponse::error('run not found', 404);
        }

        try {
            $data = JsonRequestBody::decodeAssoc($request);
        } catch (\JsonException $e) {
            return JsonResponse::error('Invalid JSON: ' . $e->getMessage(), 422);
        }

        $result = strtolower(trim((string) ($data['result'] ?? '')));
        if (!in_array($result, self::RESULTS, true)) {
            return JsonResponse::error('result must be one of: ' . implode(', ', self::RESULTS), 422);
        }

        $notes = $data['notes'] ?? null;
        $notesStr = $notes === null || $notes === '' ? null : (string) $notes;

        $chk = $this->pdo->prepare(
            'SELECT id FROM test_run_items WHERE id = :iid AND run_id = :rid LIMIT 1'
        );
        $chk->execute(['iid' => $itemId, 'rid' => $runId]);
        if (!$chk->fetchColumn()) {
            return JsonResponse::error('run item not found', 404);
        }

        $executedAt = $result === 'untested' ? null : gmdate('c');

        $upd = $this->pdo->prepare(
            'UPDATE test_run_items SET result = :result, notes = :notes, executed_at = :ex
             WHERE id = :iid AND run_id = :rid'
        );
        $upd->execute([
            'result' => $result,
            'notes' => $notesStr,
            'ex' => $executedAt,
            'iid' => $itemId,
            'rid' => $runId,
        ]);

        return JsonResponse::encode($response, [
            'data' => [
                'id' => $itemId,
                'run_id' => $runId,
                'result' => $result,
                'notes' => $notesStr,
                'executed_at' => $executedAt,
            ],
        ]);
    }

    /**
     * DELETE /api/runs/{runId}
     *
     * Cascades to all run items for the run. Test cases and suites are untouched.
     * Pass `?dry_run=1` to fetch cascade counts without deleting.
     */
    public function delete(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $runId = (int) ($args['runId'] ?? 0);
        if ($runId <= 0) {
            return JsonResponse::error('Invalid run id', 422);
        }
        $run = $this->fetchRunRow($runId);
        if ($run === null) {
            return JsonResponse::error('run not found', 404);
        }

        $itemCount = (int) $this->scalar(
            'SELECT COUNT(*) FROM test_run_items WHERE run_id = :rid',
            ['rid' => $runId]
        );
        $counts = ['run_items' => $itemCount];

        if (self::isDryRun($request)) {
            return JsonResponse::encode($response, [
                'data' => [
                    'dry_run' => true,
                    'run' => [
                        'id' => (int) $run['id'],
                        'project_id' => (int) $run['project_id'],
                        'name' => (string) $run['name'],
                    ],
                    'cascade' => $counts,
                ],
            ]);
        }

        try {
            $del = $this->pdo->prepare('DELETE FROM test_runs WHERE id = :rid');
            $del->execute(['rid' => $runId]);
        } catch (\PDOException $e) {
            error_log('DELETE /api/runs/' . $runId . ' failed: ' . $e->getMessage());
            $debug = ($_ENV['APP_DEBUG'] ?? '') === '1' || strtolower((string) ($_ENV['APP_DEBUG'] ?? '')) === 'true';

            return JsonResponse::error($debug ? $e->getMessage() : 'Database error while deleting the run.', 500);
        }

        return JsonResponse::encode($response, [
            'data' => [
                'run' => [
                    'id' => (int) $run['id'],
                    'project_id' => (int) $run['project_id'],
                    'name' => (string) $run['name'],
                ],
                'cascade' => $counts,
            ],
        ]);
    }

    /**
     * @param array<string, scalar|null> $params
     */
    private function scalar(string $sql, array $params): int|string|float|null
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $v = $stmt->fetchColumn();

        return $v === false ? 0 : $v;
    }

    private static function isDryRun(ServerRequestInterface $request): bool
    {
        $q = $request->getQueryParams();
        if (!array_key_exists('dry_run', $q)) {
            return false;
        }

        return filter_var($q['dry_run'], FILTER_VALIDATE_BOOLEAN);
    }

    private function projectExists(int $id): bool
    {
        $stmt = $this->pdo->prepare('SELECT 1 FROM projects WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);

        return (bool) $stmt->fetchColumn();
    }

    /**
     * @return array<string, mixed>|null
     */
    private function fetchSuiteRow(int $suiteId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, project_id, name FROM test_suites WHERE id = :id LIMIT 1'
        );
        $stmt->execute(['id' => $suiteId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $row;
    }

    /**
     * Section row joined with parent suite (project_id, suite name).
     *
     * @return array<string, mixed>|null
     */
    private function fetchSectionWithSuite(int $sectionId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT sec.id, sec.suite_id, sec.name AS section_name,
                    s.project_id, s.name AS suite_name
             FROM test_sections sec
             INNER JOIN test_suites s ON s.id = sec.suite_id
             WHERE sec.id = :id LIMIT 1'
        );
        $stmt->execute(['id' => $sectionId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $row;
    }

    /**
     * @return array<string, mixed>|null
     */
    private function fetchRunRow(int $runId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT r.id, r.project_id, r.suite_id, r.section_id, r.name, r.run_kind, r.state, r.created_at,
                    s.name AS suite_name,
                    sec.name AS section_name
             FROM test_runs r
             LEFT JOIN test_suites s ON s.id = r.suite_id
             LEFT JOIN test_sections sec ON sec.id = r.section_id
             WHERE r.id = :id LIMIT 1'
        );
        $stmt->execute(['id' => $runId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row === false) {
            return null;
        }
        if (!isset($row['run_kind'])) {
            $row['run_kind'] = 'full_suite';
        }
        if (!array_key_exists('section_id', $row)) {
            $row['section_id'] = null;
        }
        if (!array_key_exists('section_name', $row) || $row['section_name'] === null) {
            $row['section_name'] = null;
        }
        if (!array_key_exists('suite_name', $row)) {
            $row['suite_name'] = null;
        }

        return $row;
    }

    private static function looksLikeSqliteReadonlyError(string $message): bool
    {
        $m = strtolower($message);

        return str_contains($m, 'readonly') && str_contains($m, 'database');
    }
}
